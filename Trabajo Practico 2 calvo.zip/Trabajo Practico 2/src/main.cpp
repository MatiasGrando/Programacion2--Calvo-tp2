#include <iostream>
#include "CuatroEnLineaEnergizado.h"


using namespace std;

int main()
{
   CuatroEnLineaEnergizado juego(6,6,2);
   juego.iniciarPartida();

}
