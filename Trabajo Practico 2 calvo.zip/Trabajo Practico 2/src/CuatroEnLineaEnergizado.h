#ifndef CUATROENLINEAENERGIZADO_H
#define CUATROENLINEAENERGIZADO_H
#include "Lista.h"
#include "IndiceColumna.h"
#include <iostream>
#include "EasyBMP.h"
#define ENERGIAGANADAPORTURNO 20
using namespace std;
class CuatroEnLineaEnergizado
{
    private:
        unsigned int cantidadDeFichasEnELTablero;
        unsigned int cantidadDeJugadores;
        IndiceColumna* tableroColumnas;
        unsigned int cantidadColumnas;
        unsigned int cantidadFilas;
        Ficha* fichaAnterior;
        int turno;
        void inicializarCursorDeColumnaActualEImprimirFicha();
        void retrocederCursorDeColumnaActualEImprimirFicha();
         //imprime la primera fila e inicializa los cursores de las listas de columnas en la ultima posicion
        void imprimirPrimeraFila();
        //imprime las filas y va retrocediendo el  cursor de la lista columnas hasta llegar e imprimir el primero
        void imprimirRestoDeFilas();
        void crearTablero();
        void imprimirTablero();

        void insertarFicha(int jugador);
        void crearTableroBitmap();
        void pintarFicha(int fila,int columna, unsigned int jugador);
        bool columnaLlena(int columna);

        bool comprobarSiGano();
        bool ganoPorColumna();
        bool ganoPorFila();
        bool ganoPorEscaleraAscendente();
        bool ganoPorEscaleraDescendente();

        bool cuatroEnColumna(Columna* columnaActual,int fila);
        bool cuatroEnFila(int columna, int fila);
        bool cuatroEnEscaleraAscendente(int columna,int fila);
        bool cuatroEnEscaleraDescendente(int columna,int fila);

        Columna* posicionarseEnColumna(int columna);
        Ficha* posicionarseEnFicha(Columna* columnaActual,int fila);
        Ficha* posicionarseEnFilaLibre(Columna* columnaActual);

        void mensajeDeFinalizacionDelJuego(int jugador, bool hayGanador);

        void fluctuacionSinergia();
        void fluctuacionMitadDelTablero(int columna, int fila);
        void fluctuacionEsquinaInferiorIzquierda(int columna, int fila);
        void fluctuacionEsquinaInferiorDerecha(int columna, int fila);
        void fluctuacionEsquinaSuperiorIzquierda(int columna, int fila);
        void fluctuacionEsquinaSuperiorDerecha(int columna, int fila);
        void fluctuacionPrimeraColumna(int columna, int fila);
        void fluctuacionUltimaColumna(int columna, int fila);
        void fluctuacionPrimeraFila(int columna, int fila);
        void fluctuacionUltimaFila(int columna, int fila);
        int fluctuacionSinergiaPerisferica(unsigned int jugador, int energia,Ficha* fichaPerisferica);
        void fluctuacionSinergiaPerisfericaSegunCasos(unsigned int columna, unsigned int fila);
        void eliminarFichasSinEnergia();
        //energiza y aumenta el turno de vida de las fichas
        void energizarFichasSobrevivientes();
        void dejarCaerFichasUnCasillero(Columna* columnaActual, unsigned int fila,unsigned int columna);
        int obtenerColumnaAInsertarFicha(int jugador);
        void relacionarFichaActualConAnterior(Ficha* fichaActual);
        void fluctuacionSinergiaConFichaAnteriorYPosterior(Ficha* fichaActual);
        void fluctuacionSinergiaConFichaAnterior(Ficha* fichaActual);
        void fluctuacionSinergiaConFichaPosterior(Ficha* fichaActual);
    public:

        CuatroEnLineaEnergizado(unsigned int filas,unsigned int columnas,unsigned int jugadores);
        ~CuatroEnLineaEnergizado();
        void iniciarPartida();

};
Ficha* CuatroEnLineaEnergizado::posicionarseEnFicha(Columna* columnaActual, int fila)
{
    columnaActual->obtenerColumna()->iniciarCursor();
    for(int i =1; i< fila;i++)
    {
        columnaActual->obtenerColumna()->avanzarCursor();
    }
    Ficha* filaActual=columnaActual->obtenerColumna()->obtenerCursor()->obtenerDato();
    return filaActual;
}
bool CuatroEnLineaEnergizado::cuatroEnColumna(Columna* columnaActual,int fila)
{
    Ficha* ficha1;Ficha* ficha2;Ficha* ficha3;Ficha* ficha4;
    ficha1=posicionarseEnFicha(columnaActual,fila);
    ficha2=posicionarseEnFicha(columnaActual,fila+1);
    ficha3=posicionarseEnFicha(columnaActual,fila+2);
    ficha4=posicionarseEnFicha(columnaActual,fila+3);

    return (  ( ficha1->obtenerJugador()!=0)
            && (ficha1->obtenerJugador()==ficha2->obtenerJugador())
            && (ficha1->obtenerJugador()==ficha3->obtenerJugador())
            && (ficha1->obtenerJugador()==ficha4->obtenerJugador()));
}
bool CuatroEnLineaEnergizado::cuatroEnFila(int columna, int fila)
{
    Ficha* ficha1;Ficha* ficha2;Ficha* ficha3;Ficha* ficha4;
    Columna* columna1;Columna* columna2;Columna* columna3;Columna* columna4;
    columna1=posicionarseEnColumna(columna);
    columna2=posicionarseEnColumna(columna+1);
    columna3=posicionarseEnColumna(columna+2);
    columna4=posicionarseEnColumna(columna+3);
    ficha1=posicionarseEnFicha(columna1,fila);
    ficha2=posicionarseEnFicha(columna2,fila);
    ficha3=posicionarseEnFicha(columna3,fila);
    ficha4=posicionarseEnFicha(columna4,fila);
    return (   (ficha1->obtenerJugador()!=0)
            && (ficha1->obtenerJugador()==ficha2->obtenerJugador())
            && (ficha1->obtenerJugador()==ficha3->obtenerJugador())
            && (ficha1->obtenerJugador()==ficha4->obtenerJugador()));
}
bool CuatroEnLineaEnergizado::cuatroEnEscaleraAscendente(int columna, int fila)
{
    Ficha* ficha1;Ficha* ficha2;Ficha* ficha3;Ficha* ficha4;
    Columna* columna1;Columna* columna2;Columna* columna3;Columna* columna4;
    columna1=posicionarseEnColumna(columna);
    columna2=posicionarseEnColumna(columna+1);
    columna3=posicionarseEnColumna(columna+2);
    columna4=posicionarseEnColumna(columna+3);
    ficha1=posicionarseEnFicha(columna1,fila);
    ficha2=posicionarseEnFicha(columna2,fila+1);
    ficha3=posicionarseEnFicha(columna3,fila+2);
    ficha4=posicionarseEnFicha(columna4,fila+3);
    return (   ficha1->obtenerJugador()!=0
            && ficha1->obtenerJugador()==ficha2->obtenerJugador()
            && ficha1->obtenerJugador()==ficha3->obtenerJugador()
            && ficha1->obtenerJugador()==ficha4->obtenerJugador());
}
bool CuatroEnLineaEnergizado::cuatroEnEscaleraDescendente(int columna, int fila)
{
    Ficha* ficha1;Ficha* ficha2;Ficha* ficha3;Ficha* ficha4;
    Columna* columna1;Columna* columna2;Columna* columna3;Columna* columna4;
    columna1=posicionarseEnColumna(columna);
    columna2=posicionarseEnColumna(columna+1);
    columna3=posicionarseEnColumna(columna+2);
    columna4=posicionarseEnColumna(columna+3);
    ficha1=posicionarseEnFicha(columna1,fila+3);
    ficha2=posicionarseEnFicha(columna2,fila+2);
    ficha3=posicionarseEnFicha(columna3,fila+1);
    ficha4=posicionarseEnFicha(columna4,fila);
    return (   ficha1->obtenerJugador()!=0
            && ficha1->obtenerJugador()==ficha2->obtenerJugador()
            && ficha1->obtenerJugador()==ficha3->obtenerJugador()
            && ficha1->obtenerJugador()==ficha4->obtenerJugador());
}
bool CuatroEnLineaEnergizado::ganoPorEscaleraDescendente()
{
    bool gano=false;
    unsigned int fila=1;
    while ((gano==false)&&((cantidadFilas-3)>=fila))
    {
        unsigned int columna=1;
        while ((columna<=(cantidadColumnas-3))&&(cuatroEnEscaleraDescendente(columna,fila)==false))
        {
            columna++;
        }
        if((columna<=(cantidadColumnas-3))&&(cuatroEnEscaleraDescendente(columna,fila)==true))
        {
            gano=true;
        }
        else
        {
            fila++;
        }
    }
    return(gano);
}

bool CuatroEnLineaEnergizado::ganoPorEscaleraAscendente()
{
    bool gano=false;
    unsigned int fila=1;
    while ((gano==false)&&((cantidadFilas-3)>=fila))
    {
        unsigned int columna=1;
        while ((columna<=(cantidadColumnas-3))&&(cuatroEnEscaleraAscendente(columna,fila)==false))
        {
            columna++;
        }
        if((columna<=(cantidadColumnas-3))&&(cuatroEnEscaleraAscendente(columna,fila)==true))
        {
            gano=true;
        }
        else
        {
            fila++;
        }
    }
    return (gano);
}
bool CuatroEnLineaEnergizado::ganoPorColumna()
{
    bool gano=false;
    unsigned int columna=1;
    while((gano==false) && ((cantidadColumnas)>=columna))
    {
        Columna* columnaActual=posicionarseEnColumna(columna);
        unsigned int fila=1;
        while ((fila<=(cantidadFilas-3))&&(cuatroEnColumna(columnaActual,fila)==false))
        {
            fila++;
        }
        if((fila<=(cantidadFilas-3))&&(cuatroEnColumna(columnaActual,fila)==true))
        {
            gano=true;
        }
        else
        {
            columna++;
        }
    }
    return gano;
}
bool CuatroEnLineaEnergizado::ganoPorFila()
{
 bool gano=false;
 unsigned int fila=1;
 while ((gano==false)&&(cantidadFilas>=fila))
 {
    unsigned int columna=1;
    while ((columna<=(cantidadColumnas-3))&&(cuatroEnFila(columna,fila)==false))
    {
        columna++;
    }
    if((columna<=(cantidadColumnas-3))&&(cuatroEnFila(columna,fila)==true))
    {
        gano=true;
    }
    else
    {
        fila++;
    }
 }
 return (gano);
}
bool CuatroEnLineaEnergizado::columnaLlena(int columna)
{
    Columna* columnaActual= posicionarseEnColumna(columna);
    columnaActual->obtenerColumna()->iniciarCursorUltimo();
    Ficha* fichaActual= columnaActual->obtenerColumna()->obtenerCursor()->obtenerDato();
    return (fichaActual->obtenerJugador() != 0);
    }
bool CuatroEnLineaEnergizado::comprobarSiGano()
{
    bool gano=false;
    gano = ganoPorColumna();
    if (gano==false)
    {
        gano = ganoPorFila();
        if(gano==false)
        {
            gano= ganoPorEscaleraAscendente();
            if(gano==false)
            {
                gano= ganoPorEscaleraDescendente();
            }
        }

    }
    return gano;
}
Columna* CuatroEnLineaEnergizado::posicionarseEnColumna(int columna)
{
    this->tableroColumnas->obtenerColumnas()->iniciarCursor();
    for(int i =1; i< columna;i++)
    {
        tableroColumnas->obtenerColumnas()->avanzarCursor();
    }
    Columna* columnaActual=this->tableroColumnas->obtenerColumnas()->obtenerCursor()->obtenerDato();
    return columnaActual;
}
Ficha* CuatroEnLineaEnergizado::posicionarseEnFilaLibre(Columna* columnaActual)
{
    columnaActual->obtenerColumna()->iniciarCursor();
    Ficha* fichaActual= columnaActual->obtenerColumna()->obtenerCursor()->obtenerDato();
    if(fichaActual->obtenerJugador()!= 0)
    {
        while (fichaActual->obtenerJugador()!=0)
        {
            columnaActual->obtenerColumna()->avanzarCursor();
            fichaActual= columnaActual->obtenerColumna()->obtenerCursor()->obtenerDato();
        }
        return fichaActual;
    }
    else
    {
        return fichaActual;
    }
}
void CuatroEnLineaEnergizado::relacionarFichaActualConAnterior(Ficha* fichaActual)
{
    if(turno == 0)
    {
        this->fichaAnterior=fichaActual;
    }
    else
    {
        this->fichaAnterior->cambiarFichaPosterior(fichaActual);
        fichaActual->cambiarFichaAnterior(fichaAnterior);
        this->fichaAnterior=fichaActual;
    }
}
int CuatroEnLineaEnergizado::obtenerColumnaAInsertarFicha(int jugador)
{
    int columna;
    do
    {
        cout<<endl<<"Turno del Jugador "<<jugador<<" -------- "<<"ingrese columna"<<endl;
        cin>>columna;
        if (columnaLlena(columna) == true)
        {
                cout<<endl<<"Columna llena, ingrese otra columna la cual no se encuentre llena"<<endl;
        }
    }while(columnaLlena(columna) == true);
    return columna;
}
void CuatroEnLineaEnergizado::insertarFicha(int jugador)
{
    int columna;
    this->cantidadDeFichasEnELTablero++;
    columna=obtenerColumnaAInsertarFicha(jugador);
    Columna* columnaActual= posicionarseEnColumna(columna);
    Ficha* fichaActual= posicionarseEnFilaLibre(columnaActual);
    fichaActual->cambiarJugador(jugador);
    fichaActual->fluctuacionDeEnergia(ENERGIAMAXIMA);
    relacionarFichaActualConAnterior(fichaActual);
    this->turno++;

}
void CuatroEnLineaEnergizado::fluctuacionSinergiaConFichaAnterior(Ficha* fichaActual)
{
    int energiaPerdida=0;
    if(fichaActual->obtenerFichaAnterior()!= 0)
    {
        Ficha* fichaAntecesora = (fichaActual->obtenerFichaAnterior());
        if(fichaAntecesora->obtenerFila()>fichaActual->obtenerFila())
        {
            energiaPerdida= fichaAntecesora->obtenerFila() - fichaActual->obtenerFila();
        }
        else
        {
            energiaPerdida= fichaActual->obtenerFila() - fichaAntecesora->obtenerFila();
        }
        if (energiaPerdida>fichaActual->obtenerTurnos())
        {
            energiaPerdida= -energiaPerdida + fichaActual->obtenerTurnos();
            fichaActual->fluctuacionDeEnergia(energiaPerdida);
        }
    }
}
void CuatroEnLineaEnergizado::fluctuacionSinergiaConFichaPosterior(Ficha* fichaActual)
{
    int energiaPerdida=0;
    if (fichaActual->obtenerFichaPosterior()!=0)
    {
        Ficha* fichaPosterior = (fichaActual->obtenerFichaPosterior());
        if (fichaPosterior->obtenerColumna()>fichaActual->obtenerColumna())
        {
            energiaPerdida=fichaPosterior->obtenerColumna()- fichaActual->obtenerColumna();
        }
        else
        {
            energiaPerdida=fichaActual->obtenerColumna()-fichaPosterior->obtenerColumna();
        }
        if(energiaPerdida > (fichaActual->obtenerTurnos()-1) )
        {
            energiaPerdida= -energiaPerdida +fichaActual->obtenerTurnos() - 1 ;
            fichaActual->fluctuacionDeEnergia(energiaPerdida);

        }
    }
}
void CuatroEnLineaEnergizado::fluctuacionSinergiaConFichaAnteriorYPosterior(Ficha* fichaActual)
{
    fluctuacionSinergiaConFichaAnterior(fichaActual);
    fluctuacionSinergiaConFichaPosterior(fichaActual);

}
void CuatroEnLineaEnergizado::mensajeDeFinalizacionDelJuego(int jugador, bool hayGanador)
{
    if(hayGanador==false)
    {
        cout<<endl<<"<<<<<<<<<<<EMPATE<<<<<<<<<<"<<endl<<"----------PARTIDA FINALIZADA----------";
    }
    else
    {
        cout<<endl<<"<<<<<<<<<<GANADOR JUGADOR "<<jugador<<" <<<<<<<<<<"<<endl<<"----------PARTIDA FINALIZADA----------";
    }
}
int CuatroEnLineaEnergizado::fluctuacionSinergiaPerisferica(unsigned int jugador, int energia,Ficha* fichaPerisferica)
{
    if(jugador == fichaPerisferica->obtenerJugador() && fichaPerisferica->obtenerTurnos()<ENERGIAGANADAPORSINERGIAPERISFERICA )
    {
        int turnoViva= fichaPerisferica->obtenerTurnos();
        energia=energia+ENERGIAGANADAPORSINERGIAPERISFERICA-turnoViva;

    }
    else if (fichaPerisferica->obtenerJugador()!= 0 && fichaPerisferica->obtenerTurnos()<ENERGIAPERDIDAPORSINERGIAPERISFERICA)
    {
        int turnoViva = fichaPerisferica->obtenerTurnos();
        energia=energia-ENERGIAPERDIDAPORSINERGIAPERISFERICA+turnoViva;
    }
    return energia;
}
void CuatroEnLineaEnergizado::fluctuacionMitadDelTablero(int columnaActual,int filaActual)
{
    int energia=0;
    unsigned int jugador;
    Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual);
    jugador= fichaActual->obtenerJugador();
    if(jugador!= 0)
    {
        Ficha* fichaPerisferica;

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaActual->fluctuacionDeEnergia(energia);
    }
}
void CuatroEnLineaEnergizado::fluctuacionEsquinaInferiorDerecha(int columnaActual, int fila)
{
    int energia=0;
    unsigned int jugador;
    Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),fila);
    jugador= fichaActual->obtenerJugador();
    if (jugador != 0)
    {
        Ficha* fichaPerisferica;

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),fila+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),fila+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),fila);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaActual->fluctuacionDeEnergia(energia);
    }
}
void CuatroEnLineaEnergizado::fluctuacionEsquinaInferiorIzquierda(int columnaActual, int filaActual)
{
    int energia=0;
    unsigned int jugador;
    Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual);
    jugador= fichaActual->obtenerJugador();
    if(jugador!= 0)
    {
        Ficha* fichaPerisferica;

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaActual->fluctuacionDeEnergia(energia);

    }
}
void CuatroEnLineaEnergizado::fluctuacionEsquinaSuperiorDerecha(int columnaActual, int filaActual)
{
    int energia=0;
    unsigned int jugador;
    Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual);
    jugador= fichaActual->obtenerJugador();
    if(jugador!=0)
    {
        Ficha* fichaPerisferica;

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaActual->fluctuacionDeEnergia(energia);

    }
}
void CuatroEnLineaEnergizado::fluctuacionEsquinaSuperiorIzquierda(int columnaActual, int filaActual)
{
    int energia=0;
    unsigned int jugador;
    Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual);
    jugador= fichaActual->obtenerJugador();
    if (jugador !=0)
    {
        Ficha* fichaPerisferica;

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaActual->fluctuacionDeEnergia(energia);
    }
}
void CuatroEnLineaEnergizado::fluctuacionPrimeraColumna(int columnaActual, int filaActual)
{
    int energia=0;
    unsigned int jugador;
    Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual);
    jugador= fichaActual->obtenerJugador();
    if(jugador!=0)
    {
        Ficha* fichaPerisferica;

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaActual->fluctuacionDeEnergia(energia);
    }
}
void CuatroEnLineaEnergizado::fluctuacionUltimaColumna(int columnaActual, int filaActual)
{
    int energia=0;
    unsigned int jugador;
    Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual);
    jugador= fichaActual->obtenerJugador();
    if (jugador!=0)
    {
        Ficha* fichaPerisferica;

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual-1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaActual->fluctuacionDeEnergia(energia);

    }
}
void CuatroEnLineaEnergizado::fluctuacionPrimeraFila(int columnaActual, int filaActual)
{
    int energia=0;
    unsigned int jugador;
    Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual);
    jugador= fichaActual->obtenerJugador();
    if(jugador!= 0)
    {
        Ficha* fichaPerisferica;

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual+1);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual);
        energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

        fichaActual->fluctuacionDeEnergia(energia);
    }
}
void CuatroEnLineaEnergizado::fluctuacionUltimaFila(int columnaActual, int filaActual)
    {
        int energia=0;
        unsigned int jugador;
        Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual);
        jugador= fichaActual->obtenerJugador();
        if(jugador!= 0)
        {
            Ficha* fichaPerisferica;

            fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual);
            energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

            fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual),filaActual-1);
            energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

            fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual+1),filaActual-1);
            energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

            fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual-1);
            energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

            fichaPerisferica=posicionarseEnFicha(posicionarseEnColumna(columnaActual-1),filaActual);
            energia = fluctuacionSinergiaPerisferica(jugador,energia,fichaPerisferica);

            fichaActual->fluctuacionDeEnergia(energia);
        }
    }

void CuatroEnLineaEnergizado::fluctuacionSinergiaPerisfericaSegunCasos(unsigned int columna, unsigned int fila)
{
    if(fila==1 && columna ==1){fluctuacionEsquinaInferiorIzquierda(columna,fila);}
    else if(fila==cantidadFilas && columna ==1){fluctuacionEsquinaSuperiorIzquierda(columna,fila);}
    else if(fila==cantidadFilas && columna ==cantidadColumnas){fluctuacionEsquinaSuperiorDerecha(columna,fila);}
    else if(fila==1 && columna ==cantidadColumnas){fluctuacionEsquinaInferiorDerecha(columna,fila);}
    else if(columna ==1){fluctuacionPrimeraColumna(columna,fila);}
    else if(columna ==cantidadColumnas){fluctuacionUltimaColumna(columna,fila);}
    else if(fila==1){fluctuacionPrimeraFila(columna,fila);}
    else if(fila==cantidadFilas){fluctuacionUltimaFila(columna,fila);}
    else {fluctuacionMitadDelTablero(columna,fila);}
}
void CuatroEnLineaEnergizado::fluctuacionSinergia()
{
    unsigned int columna,fila;
    for (columna=1;columna<=cantidadColumnas;columna++)
    {
        for(fila=1;fila<=cantidadFilas;fila++)
        {
            fluctuacionSinergiaPerisfericaSegunCasos(columna,fila);
            Ficha* fichaActual=posicionarseEnFicha(posicionarseEnColumna(columna),fila);
            fluctuacionSinergiaConFichaAnteriorYPosterior(fichaActual);
        }
    }
}
void CuatroEnLineaEnergizado::dejarCaerFichasUnCasillero(Columna* columnaActual, unsigned int fila,unsigned int columna)
{
    Ficha* fichaActual = posicionarseEnFicha(columnaActual,fila);
    Ficha* fichaAnterior=fichaActual->obtenerFichaAnterior();
    Ficha* fichaPosterior=fichaActual->obtenerFichaPosterior();
    fichaAnterior->cambiarFichaPosterior(0);
    fichaPosterior->cambiarFichaAnterior(0);
    columnaActual->obtenerColumna()->eliminarElementoPosicion(fila);
    columnaActual->obtenerColumna()->agregarElemento(new Ficha(columna,this->cantidadFilas));
    for(unsigned int i =fila; i<this->cantidadFilas;i++)
    {
        fichaActual=posicionarseEnFicha(columnaActual, i);
        fichaActual->disminuirFila();
    }
}
void CuatroEnLineaEnergizado::eliminarFichasSinEnergia()
{
    unsigned int columna,fila;
    for (columna=1;columna<=cantidadColumnas;columna++)
    {
        Columna* columnaActual = posicionarseEnColumna(columna);
        for(fila=1;fila<=cantidadFilas;fila++)
        {
            Ficha* fichaActual = posicionarseEnFicha(columnaActual,fila);
            if (fichaActual->obtenerJugador()!=0 && fichaActual->obtenerEnergia()== 0)
            {
                    dejarCaerFichasUnCasillero(columnaActual,fila,columna);
                    fila--;
                    this->cantidadDeFichasEnELTablero--;
            }
        }
    }
}
void CuatroEnLineaEnergizado::energizarFichasSobrevivientes()
{
    unsigned int columna,fila;
    for (columna=1;columna<=cantidadColumnas;columna++)
    {
        for(fila=1;fila<=cantidadFilas;fila++)
        {
            Columna* columnaActual = posicionarseEnColumna(columna);
            Ficha* fichaActual = posicionarseEnFicha(columnaActual,fila);
            if (fichaActual->obtenerJugador()!= 0)
            {
                fichaActual->fluctuacionDeEnergia(ENERGIAGANADAPORTURNO);
                fichaActual->aumentarTurnos();
            }
        }
    }
}
void CuatroEnLineaEnergizado::iniciarPartida()
{
    crearTablero();
    imprimirTablero();
    bool hayGanador = false;
    unsigned int jugador;
    while ((hayGanador == false) &&(cantidadDeFichasEnELTablero<(cantidadColumnas*cantidadFilas)))
    {
        jugador=0;
        while((jugador < this->cantidadDeJugadores)&&(hayGanador == false)
            &&(cantidadDeFichasEnELTablero<(cantidadColumnas*cantidadFilas)))
        {
            jugador++;
            insertarFicha(jugador);
            hayGanador=comprobarSiGano();
            if (hayGanador == false)
            {
                fluctuacionSinergia();
                eliminarFichasSinEnergia();
                hayGanador=comprobarSiGano();
                energizarFichasSobrevivientes();
            }
            imprimirTablero();
        }
    }
    mensajeDeFinalizacionDelJuego(jugador,hayGanador);
}
CuatroEnLineaEnergizado::CuatroEnLineaEnergizado(unsigned int filas,unsigned int columnas,unsigned int jugadores)
{
    this->cantidadColumnas=columnas;
    this->cantidadFilas=filas;
    this->cantidadDeJugadores=jugadores;
    this->cantidadDeFichasEnELTablero=0;
    this->turno=0;
    tableroColumnas= new IndiceColumna;
    crearTableroBitmap();

}
void CuatroEnLineaEnergizado::crearTablero()
{
    for (unsigned int columna=0; columna<(this->cantidadColumnas);columna++)
    {
        Columna* columnaActual= new Columna;
        tableroColumnas->obtenerColumnas()->agregarElemento(columnaActual);
        for (unsigned int fila=0; fila<(this->cantidadFilas);fila++)
        {
            columnaActual->obtenerColumna()->agregarElemento(new Ficha(columna,fila));
        }
    }
}

void CuatroEnLineaEnergizado::inicializarCursorDeColumnaActualEImprimirFicha()
{
    Columna* columnaActual;
    Ficha* fichaActual;
    columnaActual= this->tableroColumnas->obtenerColumnas()->obtenerCursor()->obtenerDato();
    columnaActual->obtenerColumna()->iniciarCursorUltimo();
    fichaActual=columnaActual->obtenerColumna()->obtenerCursor()->obtenerDato();
    pintarFicha(fichaActual->obtenerFila(), fichaActual->obtenerColumna(), fichaActual->obtenerJugador());
    cout<<fichaActual->obtenerJugador()<<" "<<fichaActual->obtenerEnergia()<<"     ";
}
void CuatroEnLineaEnergizado::retrocederCursorDeColumnaActualEImprimirFicha()
{
    Columna* columnaActual;
    Ficha* fichaActual;
    columnaActual= this->tableroColumnas->obtenerColumnas()->obtenerCursor()->obtenerDato();
    columnaActual->obtenerColumna()->retrocederCursor();
    fichaActual=columnaActual->obtenerColumna()->obtenerCursor()->obtenerDato();
    pintarFicha(fichaActual->obtenerFila(), fichaActual->obtenerColumna(), fichaActual->obtenerJugador());
    cout<<fichaActual->obtenerJugador()<<" "<<fichaActual->obtenerEnergia()<<"     ";

}
void CuatroEnLineaEnergizado::imprimirPrimeraFila()
{
    this->tableroColumnas->obtenerColumnas()->iniciarCursor();
    inicializarCursorDeColumnaActualEImprimirFicha();
    while(this->tableroColumnas->obtenerColumnas()->avanzarCursor())
    {
        inicializarCursorDeColumnaActualEImprimirFicha();
    }
}
void CuatroEnLineaEnergizado::imprimirRestoDeFilas()
{
    for (unsigned int i=1; i<(this->cantidadFilas);i++)
    {
        cout<<endl<<endl<<endl;
        this->tableroColumnas->obtenerColumnas()->iniciarCursor();
        retrocederCursorDeColumnaActualEImprimirFicha();
        while(this->tableroColumnas->obtenerColumnas()->avanzarCursor())
        {
            retrocederCursorDeColumnaActualEImprimirFicha();
        }
    }
}
void CuatroEnLineaEnergizado::crearTableroBitmap()
{
	BMP Tablero;
	Tablero.SetSize(100*this->cantidadColumnas, 100*this->cantidadFilas);
	Tablero.SetBitDepth(24);
	RGBApixel Temp;
	Temp= Tablero.GetPixel(0,0);
	Temp.Red = 0; Temp.Green = 0; Temp.Blue = 0; Temp.Alpha = 0;
	for (unsigned int i=0; i< this->cantidadColumnas*100 ; i+=100){
		for (unsigned int j = 0; j<this->cantidadFilas*100; j++){

			Tablero.SetPixel(i,j,Temp);
		}
	}
	for (unsigned int i=0; i< this->cantidadColumnas*100; i++){
		for (unsigned int j = 0; j<this->cantidadFilas*100; j+=100){
			Tablero.SetPixel(i,j,Temp);

		}
	}

	Tablero.WriteToFile("Tablero.bmp");

}
void CuatroEnLineaEnergizado::pintarFicha(int fila, int columna, unsigned int jugador)
{
	BMP ficha;
	ficha.ReadFromFile("Tablero.bmp");
	RGBApixel Temp;
	Temp = ficha.GetPixel(0, 0);
	if (jugador==1){
		Temp.Red = 255; Temp.Green = 0; Temp.Blue = 0; Temp.Alpha = 0;
	}else if(jugador ==2){
		Temp.Red = 0; Temp.Green = 0; Temp.Blue = 255; Temp.Alpha = 0;
	}else if (jugador ==0){
		return;
	}else{
		Temp.Red = jugador*70; Temp.Green = jugador*50; Temp.Blue = jugador*30; Temp.Alpha = 0;
	}

	fila = this->cantidadFilas - fila -1;
	cout << fila;

	//Temp.Red = 0; Temp.Green = 0; Temp.Blue = 255; Temp.Alpha = 0;
	for (int i=fila*100; i<= fila*100 +99; i++){
		for (int j = columna*100; j<=columna*100 +99; j++){

			ficha.SetPixel(j,i,Temp);
		}
	}
	ficha.WriteToFile("Tablero.bmp");

}
void CuatroEnLineaEnergizado::imprimirTablero()
{
    imprimirPrimeraFila();
    imprimirRestoDeFilas();
}
CuatroEnLineaEnergizado::~CuatroEnLineaEnergizado()
{
    delete tableroColumnas;
}
#endif // CUATROENLINEAENERGIZADO_H
