#ifndef COLUMNA_H
#define COLUMNA_H
#include "Ficha.h"


class Columna
{
    public:
        Columna();
        ~Columna();
        Lista<Ficha*>*  obtenerColumna();


    private:
        Lista<Ficha*>* ColumnaDeFichas;
};
Columna::Columna()
{
    this->ColumnaDeFichas=new Lista<Ficha*>;
}
Columna::~Columna()
{
    delete obtenerColumna();
}

Lista<Ficha*>* Columna::obtenerColumna()
{
    return this->ColumnaDeFichas;
}

#endif // COLUMNA_H
