#ifndef INDICECOLUMNA_H
#define INDICECOLUMNA_H
#include "Columna.h"

class IndiceColumna
{
    public:
        IndiceColumna();
        ~IndiceColumna();
        Lista<Columna*>* obtenerColumnas();

    private:
        Lista<Columna*>* listaColumnas;
};

IndiceColumna::IndiceColumna()
{
    this->listaColumnas=new Lista<Columna*>;
}
IndiceColumna::~IndiceColumna()
{
    delete obtenerColumnas();
}

Lista<Columna*>* IndiceColumna::obtenerColumnas()
{
    return this->listaColumnas;
}

#endif // INDICECOLUMNA_H
