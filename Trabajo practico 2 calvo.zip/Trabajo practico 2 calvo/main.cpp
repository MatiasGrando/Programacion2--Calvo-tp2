#include <iostream>
#include "Consola.h"


using namespace std;

int main()
{
   iniciarConsola();

}
