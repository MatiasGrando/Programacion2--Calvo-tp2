#include "CuatroEnLineaEnergizado.h"

CuatroEnLineaEnergizado::CuatroEnLineaEnergizado()
{
    //ctor
}

CuatroEnLineaEnergizado::~CuatroEnLineaEnergizado()
{
    //dtor
}
