#include "IndiceColumna.h"

IndiceColumna::IndiceColumna()
{
    //ctor
}

IndiceColumna::~IndiceColumna()
{
    //dtor
}
