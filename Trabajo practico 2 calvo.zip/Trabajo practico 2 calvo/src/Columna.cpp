#include "Columna.h"

Columna::Columna()
{
    //ctor
}

Columna::~Columna()
{
    //dtor
}
